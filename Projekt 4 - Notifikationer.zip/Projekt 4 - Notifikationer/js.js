function openPopup() {
    document.getElementById("popup-container").style.display = "block";
  }
  
  function closePopup() {
    document.getElementById("popup-container").style.display = "none";
  }
  